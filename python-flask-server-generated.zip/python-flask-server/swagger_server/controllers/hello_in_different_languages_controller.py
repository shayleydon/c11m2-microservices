import connexion
import six

from swagger_server import util


def greetings_get():  # noqa: E501
    """Returns a list of Greetings

    Returns greetings in different languages # noqa: E501


    :rtype: None
    """
    return 'do some magic!'
